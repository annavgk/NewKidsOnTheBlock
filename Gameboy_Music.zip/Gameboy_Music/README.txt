CREDITS:

Menu music - https://freesound.org/people/orginaljun/sounds/396960/
Game music - https://freesound.org/people/Rolly-SFX/sounds/626274/